#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <istream>
#include <cstdlib>
#include "CLASS.h"
#include "DETAIL.cpp"
using namespace std;

int main(void)
{   
    DATA data;
    vector<vector<DATA*>> Enroll;
    vector <DATA*> enroll;

    string month_route[12] = {
        "/home/lms/Cpp_project/Team/농산물/201301.csv",       // 1월
        "/home/lms/Cpp_project/Team/농산물/201302.csv",       // 2월
        "/home/lms/Cpp_project/Team/농산물/201303.csv",       // 3월
        "/home/lms/Cpp_project/Team/농산물/201304.csv",       // 4월
        "/home/lms/Cpp_project/Team/농산물/201305.csv",       // 5월
        "/home/lms/Cpp_project/Team/농산물/201306.csv",       // 6월
        "/home/lms/Cpp_project/Team/농산물/201307.csv",       // 7월
        "/home/lms/Cpp_project/Team/농산물/201308.csv",       // 8월
        "/home/lms/Cpp_project/Team/농산물/201309.csv",       // 9월
        "/home/lms/Cpp_project/Team/농산물/201310.csv",       // 10월
        "/home/lms/Cpp_project/Team/농산물/201311.csv",       // 11월
        "/home/lms/Cpp_project/Team/농산물/201312.csv"        // 12월
        };

    int len[12];
    for ( int i = 0 ; i < 12 ; i++)
        {
            enroll = read_file(month_route[i]);
            Enroll.push_back(enroll);
        }
    int choice;

    while(1) 
    {
        cout << "원하는 항목을 입력해주세요." << endl;
        cout << "1. 지역별 가격 조회       2. 월별 가격 조회       3. 품목별 가격 조회" << endl;
        cout << "4. 새로운 파일 추가       5. 파일 수정            6. 종료" << endl;
        cin >> choice;
        switch (choice)
        {
            case 1 : data.location_calculate(Enroll);
                     break;
            case 2 : data.month_calculate(Enroll);
                     break;
            case 3 : data.product_calculate(Enroll);
                     break;
            case 4 : enroll = PULS_read_file("/home/lms/Cpp_project/Team/농산물/202201.csv");
                     Enroll.push_back(enroll);
                     month_num++;
                     break;
            case 5 : int i;
                     cout << "1~12월 중 수정할 파일날짜를 입력해주세요 : ";
                     cin >> i;
                     enroll = read_file(month_route[i-1]);     //수정
                     data.fix(enroll, month_route[i-1]);
                     break;
            case 6 : exit(1);
        }                      
    }

    return 0;
}
