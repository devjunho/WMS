#ifndef __HEAD_H__
#define __HEAD_H__

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <istream>
#include <cstdlib>
using namespace std;

class DATA
{
public:
    string date;                // 조사일
    string location;            // 조사지역명
    string location_n;          // 조사지역코드
    string market;              // 조사시장명
    string market_n;            // 조사시장코드
    string product;             // 품목명
    string product_n;           // 품목코드
    string country;             // 종류명
    string sale_type;           // 유통단계
    string sale_type_n;         // 유통단계 구분
    string pride_n;             // 등급코드
    string weight;              // 규격
    string price;               // 조사가격
    DATA();
    DATA(string, string, string, string, string, string, string, string, string, string, string, string, string);
    vector <string> read_row(istream &, char);
    vector <DATA*> read_file(string address);
    vector <DATA*> PULS_read_file(string address);
    void location_calculate(vector<vector<DATA*>> &enroll);
    void month_calculate(vector<vector<DATA*>> &enroll);
    void product_calculate(vector<vector<DATA*>> &enroll);
    void fix(vector<DATA*> &enroll, string data);    
};

#endif