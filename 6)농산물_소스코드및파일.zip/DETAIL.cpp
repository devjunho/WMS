#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <istream>
#include <cstdlib>
#include <algorithm>
#include "CLASS.h"
using namespace std;
int month_num = 12;

DATA::DATA(){}

DATA::DATA(string d_t, string l_c, string l_c_n, string m_k, string m_k_n, string p_d, string p_d_n, string c_t, string s_t, string s_t_n, string prid_n, string w_t, string p_i)
{
    date = d_t;
    location = l_c;
    location_n = l_c_n;
    market = m_k;
    market_n = m_k_n;
    product = p_d;
    product_n = p_d_n;
    country = c_t;
    sale_type = s_t;
    sale_type_n = s_t_n;
    pride_n = prid_n;
    weight = w_t;
    price = p_i;
}

vector <string> read_row(istream &file, char delimiter)
{
    stringstream ss;
    bool inquotes = false;
    vector <string> row;

    while(file.good())
    {
        char c = file.get();
        if(!inquotes && c == '"')
        {
            inquotes = true;
        }
        else if(inquotes && c == '"')
        {
            if(file.peek() == '"')
            {
                ss << (char)file.get();
            }
            else
            {
                inquotes = false;
            }
        }
        else if(!inquotes &&c == delimiter)
        {
            row.push_back(ss.str());
            ss.str("");
        }
        else if(!inquotes && (c == '\r' || c == '\n'))
        {
            if(file.peek() == '\n'){file.get();}
            row.push_back(ss.str());
            return row;
        }
        else
        {
            ss << c;
        }
    }
    return row;
}

vector <DATA*> read_file(string address)
{
    int num = 0;                            // 클래스 포인터 벡터 배열 순서
    DATA* Penroll;
    vector <DATA*> enroll;                 // '1달 - 각 줄마다'의 클래스를 가리키고 있는 클래스 포인터 벡터 배열

    ifstream file(address);
    if(file.fail())
    {
        cout << "해당 경로에 위치하는 파일이 존재하지 않습니다" << endl;
        return enroll;
    }
    while(file.good())
    {
        vector <string> row = read_row(file,',');
        int len = row.size() -1;
        string temp[16];                   // 한 줄마다의 각각 변수 멤버를 담을 temp 박스
        int j = 0;                          // temp 순서
        for (int i = 0, len = row.size() -1 ; i < len ; i++)
        {
            temp[j] = row[i];
            j++;
        }
        Penroll = new DATA (temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6], temp[7], temp[9], temp[10], temp[12], temp[13], temp[14]);
        enroll.push_back(Penroll);
        for (int i=0; i< len; i++)
        {    
            temp[i] = {0};
        }
        num++;
    }
    file. close();
    return enroll;
}

vector <DATA*> PULS_read_file(string address)
{
    int num = 0;                            // 클래스 포인터 벡터 배열 순서
    DATA* Penroll;
    vector <DATA*> enroll;                 // '1달 - 각 줄마다'의 클래스를 가리키고 있는 클래스 포인터 벡터 배열

    ifstream file(address);
    if(file.fail())
    {
        cout << "해당 경로에 위치하는 파일이 존재하지 않습니다" << endl;
        return enroll;
    }
    while(file.good())
    {
        vector <string> row = read_row(file,',');
        int len = row.size() -1;
        string temp[16];                   // 한 줄마다의 각각 변수 멤버를 담을 temp 박스
        int j = 0;                          // temp 순서
        for (int i = 0, len = row.size() -1 ; i < len ; i++)
        {
            temp[j] = row[i];
            j++;
        }
        Penroll = new DATA (temp[0], temp[1], temp[2], temp[3], temp[6], temp[10], temp[4], temp[5], temp[7], temp[11],temp[15],temp[14], temp[12]);
        enroll.push_back(Penroll);
        for (int i=0; i< len; i++)
        {    
            temp[i] = {0};
        }
        num++;
    }
    file. close();
    return enroll;
}

void DATA::location_calculate(vector<vector<DATA*>> &enroll)      //지역별
{
    int choice;
    int max = 0; 
    int max1 = 0;
    int min = 1000000; 
    int min1 = 1000000;
    int avg = 0; 
    int avg1 = 0;
    float tot = 0;
    float tot1 = 0;
    double count =1;
    double count1 =1;
    string market;
    string market1;
    string product;
    string product1;
    string lor;     //선택지역
    string str;     //선택 품목

    vector<string> check;
    vector<string> check2;
    for(int i = 0; i < month_num; i++)
    {
        for(int j=0; j < enroll[i].size(); j++)
        {
            if (find(check.begin(), check.end(),enroll[i][j]->location) == check.end())
                check.emplace_back(enroll[i][j]->location);
        }
    }

    cout << "[ 조회 원하시는 것을 입력 부탁드립니다 ]" << endl;
    cout << "========================================================================================" << endl;
    for (int i = 0; i < check.size(); i++)
    {
        cout << check.at(i)<< ' ';
        if ( i % 10 == 0)
        {cout << endl;}
    }
    cout << endl << "========================================================================================" << endl;
    cout << " 입력 : " <<endl;
    cin >> lor;


    //선택한 지역의 품목
    for(int i = 0; i < month_num; i++)
    {
        for(int j=0; j<enroll[i].size(); j++)
        {
            if(enroll[i][j]->location == lor)
            {
                if(find(check2.begin(), check2.end(),enroll[i][j]->product) == check2.end())
                    check2.emplace_back(enroll[i][j]->product);
            }
            
        }
    }
    cout << "[ 조회 원하시는 것을 입력 부탁드립니다 ]" <<endl;
    cout << "========================================================================================" <<endl;
    for (int i = 0; i < check2.size(); i++)
    {
        cout << check2.at(i)<< ' ';
        if ( i % 10 == 0)
        {cout << endl;}
    }
    cout << endl<<"========================================================================================" <<endl;
    cin >> str;
    cout << "1) 최대값     2) 최소값    3) 평균값" << endl;
    cout << ":  ";
    cin >> choice;
    if(choice == 1)
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            {  
                if (enroll[i][j]->location == lor) 
                {
                    if (enroll[i][j]->product == str)
                    {   
                        if(enroll[i][j]->sale_type_n == "6")
                        {
                            if(max < atoi(enroll[i][j]->price.c_str()))
                            {
                                max = atoi(enroll[i][j]->price.c_str());
                                market = enroll[i][j]->market;
                                product = enroll[i][j]->product;
                            }
                        }
                        else if(enroll[i][j]->sale_type_n == "7")
                        {
                            if(max1 < atoi(enroll[i][j]->price.c_str()))
                            {
                                max1 = atoi(enroll[i][j]->price.c_str());
                                market1 = enroll[i][j]->market;
                                product1 = enroll[i][j]->product;
                            }
                        }
                    }
                }    
            }
        }
        if(max !=0)
        {
            cout << "도매: "; 
            cout << max << "  " <<
                    market << "  "<<
                    product << endl;
        }
        if(max1 !=0)
        {
            cout << "소매: ";
            cout << max1 << "  " <<
                    market1 << "  "<<
                    product1 << endl;
        }
    }
    else if(choice == 2)
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            {  
                if (enroll[i][j]->location == lor) 
                {
                    if (enroll[i][j]->product == str)
                    {   
                        if(enroll[i][j]->sale_type_n == "6")
                        {
                            if(min > atoi(enroll[i][j]->price.c_str()))
                            {
                                min = atoi(enroll[i][j]->price.c_str());
                                market = enroll[i][j]->market;
                                product = enroll[i][j]->product;
                            }
                        }
                        else if(enroll[i][j]->sale_type_n == "7")
                        {
                            if(min1 > atoi(enroll[i][j]->price.c_str()))
                            {
                                min1 = atoi(enroll[i][j]->price.c_str());
                                market1 = enroll[i][j]->market;
                                product1 = enroll[i][j]->product;
                            }
                        }
                    }
                }    
            }
    }
        if(min != 1000000)
        {
            cout << "도매: "; 
            cout << min << "  " <<
                    market << "  "<<
                    product << endl;
        }
        if(min1 != 1000000)
        {
            cout << "소매: ";
            cout << min1 << "  " <<
                    market1 << "  "<<
                    product1 << endl;
        }
    }
    else
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            {  
                if (enroll[i][j]->location == lor) 
                {
                    if (enroll[i][j]->product == str)
                    {   
                        if(enroll[i][j]->sale_type_n == "6")
                        {
                            tot += atoi(enroll[i][j]->price.c_str());
                            market = enroll[i][j]->market;
                            product = enroll[i][j]->product;
                            count++;
                        }
                        else if(enroll[i][j]->sale_type_n == "7")
                        {
                            tot1 += atoi(enroll[i][j]->price.c_str());
                            market1 = enroll[i][j]->market;
                            product1 = enroll[i][j]->product;
                            count1++;
                        }
                    }
                }    
            }
        }
        avg = tot / count;
        avg1 = tot1 / count1;
        if(tot !=0)
        {
            cout << "도매" << endl; 
            cout  << "평균: " <<
                    avg << "  " <<
                    market << "  "<<
                    product << endl;
        }
        if(tot1 !=0)
        {
            cout << "소매" << endl;
            cout  << "평균: "<<
                    avg1 << "  " <<
                    market1 << "  " <<
                    product1 << endl;
        }
    }
}

void DATA::month_calculate(vector<vector<DATA*>> &enroll)             // 월별
{
    int choice;
    int max = 0; 
    int max1 = 0;
    int min = 1000000; 
    int min1 = 1000000;
    int avg = 0; 
    int avg1 = 0;
    float tot = 0;
    float tot1 = 0;
    double count =1;
    double count1 =1;
    string answer;
    string market;
    string market1;
    string product;
    string product1;
    string month;
    string month1;
    string lor;     //선택지역
    string str;     //선택 품목

    vector<string> check;
    vector<string> check2;
    for(int i=0; i < month_num; i++)
    {
        for (int j=0; j < month_num; j++)
        {
            if (find(check.begin(), check.end(),enroll[i][j]->date.substr(0, 6)) == check.end())
                check.emplace_back(enroll[i][j]->date.substr(0, 6));
        }
    }
    cout << "[ 조회 원하시는 것을 입력 부탁드립니다 ]" <<endl;
    cout << "========================================================================================" << endl;
    for (int i = 0; i < check.size(); i++)
    {   
        cout << check.at(i)<< ' ';
        if ( i % 10 == 0)
          cout << endl;
    }
    cout << endl <<"========================================================================================" << endl;
    cin >> answer;

    //선택한 지역의 품목
    for (int i = 0; i < month_num; i++)
    {
        for(int j=0; j<enroll[i].size(); j++)
        {
            if (find(check2.begin(), check2.end(),enroll[i][j]->product) == check2.end())
                check2.emplace_back(enroll[i][j]->product);
        }
    }
    cout << "[ 조회 원하시는 것을 입력 부탁드립니다 ]" <<endl;
    cout << "========================================================================================" << endl;
    for (int i = 0; i < check2.size(); i++)
    {
        cout << check2.at(i)<< ' ';
        if ( i % 10 == 0)
        {cout << endl;}
    }
    cout << endl << "========================================================================================" <<endl;
    cin >> str;
    // getline(cin, str);
    cout << "1) 최대값     2) 최소값    3) 평균값" << endl;
    cout << ":  ";
    cin >> choice;
    if(choice == 1)
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            { 
                if(enroll[i][j]->date.find(answer) != string::npos)
                {
                    if (enroll[i][j]->product == str)
                    {   
                        if(enroll[i][j]->sale_type_n == "6")
                        {
                            if(max < atoi(enroll[i][j]->price.c_str()))
                            {
                                max = atoi(enroll[i][j]->price.c_str());
                                product = enroll[i][j]->product;
                                month = enroll[i][j]->date;
                            }
                        }

                        else if(enroll[i][j]->sale_type_n == "7")
                        {
                            if(max1 < atoi(enroll[i][j]->price.c_str()))
                            {
                                max1 = atoi(enroll[i][j]->price.c_str());
                                product1 = enroll[i][j]->product;
                                month1 = enroll[i][j]->date;
                            }
                        }
                    }
                }    
            }
            if(max !=0)
            {
            cout << "도매: "; 
            cout << month << "  "<<
                    max << "  " <<
                    product << endl;
            }
            if(max1 !=0)
            {
            cout << "소매: ";
            cout << month1 << "  "<<
                    max1 << "  " <<
                    product1 << endl;
            }
            max = 0; 
            max1 = 0;
        } 
    }
    else if(choice == 2)
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            { 
                if(enroll[i][j]->date.find(answer) != string::npos)
                {
                    if (enroll[i][j]->product == str)
                    {   
                        if(enroll[i][j]->sale_type_n == "6")
                        {
                            if(min > atoi(enroll[i][j]->price.c_str()))
                            {
                                min = atoi(enroll[i][j]->price.c_str());
                                product = enroll[i][j]->product;
                                month = enroll[i][j]->date;
                            }
                        }
                        else if(enroll[i][j]->sale_type_n == "7")
                        {
                            if(min1 > atoi(enroll[i][j]->price.c_str()))
                            {
                                min1 = atoi(enroll[i][j]->price.c_str());
                                product1 = enroll[i][j]->product;
                                month1 = enroll[i][j]->date;
                            }
                        }
                    }
                }    
            }
        }
        if(min !=1000000)
            {
            cout << "도매: "; 
            cout << month<< "  "<<
                    min << "  " <<
                    product << endl;
            }
            else if (min ==1000000)
                cout << "없음" << endl;
            
            if(min1 !=1000000)
            {
            cout << "소매: ";
            cout << month1 << "  "<<
                    min1 << "  " <<
                    product1 << endl;
            }
            else if (min ==1000000)
                cout << "없음" << endl;
            min = 1000000; 
            min1 = 1000000; 

    }
    else
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            {  
                if(enroll[i][j]->date.find(answer) != string::npos)
                {
                    if (enroll[i][j]->product == str)
                    {   
                        if(enroll[i][j]->sale_type_n == "6")
                        {
                            tot += atoi(enroll[i][j]->price.c_str());
                            market = enroll[i][j]->market;
                            product = enroll[i][j]->product;
                            count++;
                        }
                        else if(enroll[i][j]->sale_type_n == "7")
                        {
                            tot1 += atoi(enroll[i][j]->price.c_str());
                            market1 = enroll[i][j]->market;
                            product1 = enroll[i][j]->product;
                            count1++;
                        }
                    }
                }    
            }
        }
        avg = tot / count;
        avg1 = tot1 / count1;
        if(tot !=0)
        {
            cout << "도매" << endl; 
            cout  << "평균: " <<
                    avg << "  " <<
                    market << "  "<<
                    product << endl;
        }
        if(tot1 !=0)
        {
            cout << "소매" << endl;
            cout  << "평균: "<<
                    avg1 << "  " <<
                    market1 << "  " <<
                    product1 << endl;
        }
    }
}

void DATA::product_calculate(vector<vector<DATA*>> &enroll)       // 상품별
{
    int choice;
    int max = 0; 
    int max1 = 0;
    int min = 1000000; 
    int min1 = 1000000;
    int avg = 0; 
    int avg1 = 0;
    float tot = 0;
    float tot1 = 0;
    double count =1;
    double count1 =1;
    string date;
    string date1;
    string market;
    string market1;
    string product;
    string product1;
    string lor;     //선택지역
    string str;     //선택 품목

    vector<string> check;

    //선택한 지역의 품목
    for (int i = 0; i < month_num; i++)
    {
        for(int j=0; j<enroll[i].size(); j++)
        {
            if (find(check.begin(), check.end(),enroll[i][j]->product) == check.end())
                    check.emplace_back(enroll[i][j]->product);
        }
    }
    cout << "[ 조회 원하시는 것을 입력 부탁드립니다 ]" <<endl;
    cout << "========================================================================================" <<endl;
    for (int i = 0; i < check.size(); i++)
    {
        cout << check.at(i)<< ' ';
        if ( i % 10 == 0)
        {cout << endl;}
    }
    cout << endl<<"========================================================================================" <<endl;
    cin >> str;
    cout << "1) 최대값     2) 최소값    3) 평균값" << endl;
    cout << ":  ";
    cin >> choice;
    if(choice == 1)
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            {  
                if (enroll[i][j]->product == str)
                {   
                    if(enroll[i][j]->sale_type_n == "6")
                    {
                        if(max < atoi(enroll[i][j]->price.c_str()))
                        {
                            max = atoi(enroll[i][j]->price.c_str());
                            date = enroll[i][j]->date;
                            market = enroll[i][j]->market;
                        }
                    }
                    else if(enroll[i][j]->sale_type_n == "7")
                    {
                        if(max1 < atoi(enroll[i][j]->price.c_str()))
                        {
                            max1 = atoi(enroll[i][j]->price.c_str());
                            date1 = enroll[i][j]->date;
                            market1 = enroll[i][j]->market;
                        }
                    }
                }
            }
        }
        cout << "도매: ";
        cout << date << "  " <<
                max << "  " <<
                market << endl;
        cout << "소매: ";
        cout << date1 << "  " <<
                max1 << "  " <<
                market1 << endl;
    }
    else if(choice == 2)
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            {  
                if (enroll[i][j]->product == str)
                {   
                    if(enroll[i][j]->sale_type_n == "6")
                    {
                        if(min > atoi(enroll[i][j]->price.c_str()))
                        {
                            min = atoi(enroll[i][j]->price.c_str());
                            date = enroll[i][j]->date;
                            market = enroll[i][j]->market;
                        }
                    }
                    else if(enroll[i][j]->sale_type_n == "7")
                    {
                        if(min1 > atoi(enroll[i][j]->price.c_str()))
                        {
                            min1 = atoi(enroll[i][j]->price.c_str());
                            date1 = enroll[i][j]->date;
                            market1 = enroll[i][j]->market;
                        }
                    }
                }
            }
        }
        if(min != 1000000)
        cout << "도매: ";
        cout << date << "  " <<
                min << "  " <<
                market << endl;
        if(min1 != 1000000)
        cout << "소매: ";
        cout << date1 << "  " <<
                min1 << "  " <<
                market1 << endl;
        min = 1000000; 
        min1 = 1000000;    
    }
    else
    {
        for (int i = 0; i < month_num; i++)
        {
            for(int j=0; j<enroll[i].size(); j++)
            {  
                if (enroll[i][j]->product == str)
                {   
                    if(enroll[i][j]->sale_type_n == "6")
                    {
                        
                        {
                            tot += atoi(enroll[i][j]->price.c_str());
                            date = enroll[i][j]->date;
                            market = enroll[i][j]->market;
                            count++;
                        }
                    }
                    else if(enroll[i][j]->sale_type_n == "7")
                    {
                        
                        {
                            tot1 += atoi(enroll[i][j]->price.c_str());
                            date1 = enroll[i][j]->date;
                            market1 = enroll[i][j]->market;
                            count1++;
                        }
                    }
                }
            }
        }
        avg = tot / count;
        avg1 = tot1 / count1;
        if(tot !=0)
        {
            cout << "도매" << endl; 
            cout  << "평균: " <<
                    avg << "  " <<
                    market << "  "<<
                    product << endl;
        }
        if(tot1 !=0)
        {
            cout << "소매" << endl;
            cout  << "평균: "<<
                    avg1 << "  " <<
                    market1 << "  " <<
                    product1 << endl;
        }
    }
}

void DATA::fix(vector<DATA*> &enroll, string data)
{
  
    ofstream ofs(data);
    
    //수정할 데이터 상품가격으로 할 경우

    string input_p;    
    string change;
    cout <<"수정하고 싶은 상품을 입력하세요: "<< endl;
    cin >> input_p;
    cout << endl << "상품명을 수정하세요"<< endl;
    cin >> change; 
    cout << input_p << "이(가) " << change << "로 수정됐습니다." << endl;
    for ( int j = 0 ; j < enroll.size(); j++)
    {
            if(enroll[j]->product == input_p)
            {           
                enroll[j]->product= change;
            }   
    }
   
    for (int j = 0 ; j < enroll.size();j++)
    {
        ofs << enroll[j]->date << "," 
            << enroll[j]->location <<","
            << enroll[j]->location_n << ","
            << enroll[j]->market << ","
            << enroll[j]->market_n << ","
            << enroll[j]->product << ","
            << enroll[j]->product_n << ","
            << enroll[j]->country << ","
            << enroll[j]->sale_type << ","
            << enroll[j]->sale_type_n << ","
            << enroll[j]->pride_n << ","
            << enroll[j]->weight << ","
            << enroll[j]->price << ",";  
        ofs << endl;
    }
}

